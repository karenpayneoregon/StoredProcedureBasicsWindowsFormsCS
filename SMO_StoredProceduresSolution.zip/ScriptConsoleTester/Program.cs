﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ScriptingLibrary;

namespace ScriptConsoleTester
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = new StoredProcedureScripter();
            test.Execute(
                "KARENS-PC", 
                "CustomerDatabase", 
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "results.txt"));
        }
    }
}
