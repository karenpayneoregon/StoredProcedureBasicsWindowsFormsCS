﻿using System.Collections.Generic;
using System.Data;
using Microsoft.SqlServer.Management.Sdk.Sfc;
using Microsoft.SqlServer.Management.Smo;

namespace ScriptingLibrary
{
    public class StoredProcedureScripter
    {
        /// <summary>
        /// Script stored procedures from a specific database residing in a specific
        /// SQL-Server instance
        /// </summary>
        /// <param name="pServerName">Name of SQL-Server</param>
        /// <param name="pCatalogName">Catalog to traverse Stored Procedures on</param>
        /// <param name="pFileName">File name and path to write Stored Procedures too</param>
        /// <remarks>
        /// Exception handling intentionally left out. At least there should be a try/catch
        /// around this method from the caller of this method.
        /// </remarks>
        public void Execute(string pServerName, string pCatalogName, string pFileName)
        {
            Server server = new Server(pServerName);
            Database database = server.Databases[pCatalogName];

            var sqlSmoObjectList = new List<SqlSmoObject>();
            DataTable dataTable = database.EnumObjects(DatabaseObjectTypes.StoredProcedure);

            foreach (DataRow row in dataTable.Rows)
            {
                var currentSchema = (string)row["Schema"];

                if (currentSchema == "sys" || currentSchema == "INFORMATION_SCHEMA")
                {
                    continue;
                }

                var sp = (StoredProcedure)server.GetSmoObject(new Urn((string)row["Urn"]));

                if (!sp.IsSystemObject)
                {
                    sqlSmoObjectList.Add(sp);
                }

            }

            var scriptWriter = new Scripter 
            {
                Server = server, Options =
                {
                    IncludeHeaders = true,
                    SchemaQualify = true,
                    ToFileOnly = true,
                    FileName = pFileName
                }
            };

            scriptWriter.Script(sqlSmoObjectList.ToArray());

        }
    }
}
